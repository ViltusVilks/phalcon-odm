
extern zend_class_entry *phalcon_crypt_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Crypt_Exception);

