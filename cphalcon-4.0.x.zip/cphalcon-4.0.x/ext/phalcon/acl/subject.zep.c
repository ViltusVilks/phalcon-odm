
#ifdef HAVE_CONFIG_H
#include "../../ext_config.h"
#endif

#include <php.h>
#include "../../php_ext.h"
#include "../../ext.h"

#include <Zend/zend_operators.h>
#include <Zend/zend_exceptions.h>
#include <Zend/zend_interfaces.h>

#include "kernel/main.h"
#include "kernel/object.h"
#include "kernel/operators.h"
#include "kernel/exception.h"
#include "ext/spl/spl_exceptions.h"
#include "kernel/memory.h"


/**
 * This file is part of the Phalcon Framework.
 *
 * (c) Phalcon Team <team@phalconphp.com>
 *
 * For the full copyright and license information, please view the LICENSE.txt
 * file that was distributed with this source code.
 */
/**
 * Phalcon\Acl\Subject
 *
 * This class defines subject entity and its description
 */
ZEPHIR_INIT_CLASS(Phalcon_Acl_Subject) {

	ZEPHIR_REGISTER_CLASS(Phalcon\\Acl, Subject, phalcon, acl_subject, phalcon_acl_subject_method_entry, 0);

	/**
	 * Subject description
	 * @var string
	 */
	zend_declare_property_null(phalcon_acl_subject_ce, SL("description"), ZEND_ACC_PRIVATE TSRMLS_CC);

	/**
	 * Subject name
	 * @var string
	 */
	zend_declare_property_null(phalcon_acl_subject_ce, SL("name"), ZEND_ACC_PRIVATE TSRMLS_CC);

	zend_class_implements(phalcon_acl_subject_ce TSRMLS_CC, 1, phalcon_acl_subjectinterface_ce);
	return SUCCESS;

}

/**
 * Subject description
 */
PHP_METHOD(Phalcon_Acl_Subject, getDescription) {

	zval *this_ptr = getThis();


	RETURN_MEMBER(getThis(), "description");

}

/**
 * Subject name
 */
PHP_METHOD(Phalcon_Acl_Subject, getName) {

	zval *this_ptr = getThis();


	RETURN_MEMBER(getThis(), "name");

}

/**
 * Subject name
 */
PHP_METHOD(Phalcon_Acl_Subject, __toString) {

	zval *this_ptr = getThis();


	RETURN_MEMBER(getThis(), "name");

}

/**
 * Phalcon\Acl\Subject constructor
 */
PHP_METHOD(Phalcon_Acl_Subject, __construct) {

	zval *name_param = NULL, *description_param = NULL;
	zval name, description;
	zval *this_ptr = getThis();

	ZVAL_UNDEF(&name);
	ZVAL_UNDEF(&description);

	ZEPHIR_MM_GROW();
	zephir_fetch_params(1, 1, 1, &name_param, &description_param);

	if (UNEXPECTED(Z_TYPE_P(name_param) != IS_STRING && Z_TYPE_P(name_param) != IS_NULL)) {
		zephir_throw_exception_string(spl_ce_InvalidArgumentException, SL("Parameter 'name' must be of the type string") TSRMLS_CC);
		RETURN_MM_NULL();
	}
	if (EXPECTED(Z_TYPE_P(name_param) == IS_STRING)) {
		zephir_get_strval(&name, name_param);
	} else {
		ZEPHIR_INIT_VAR(&name);
		ZVAL_EMPTY_STRING(&name);
	}
	if (!description_param) {
		ZEPHIR_INIT_VAR(&description);
		ZVAL_STRING(&description, "");
	} else {
		zephir_get_strval(&description, description_param);
	}


	if (ZEPHIR_IS_STRING(&name, "*")) {
		ZEPHIR_THROW_EXCEPTION_DEBUG_STR(phalcon_acl_exception_ce, "Subject name cannot be '*'", "phalcon/acl/subject.zep", 41);
		return;
	}
	zephir_update_property_zval(this_ptr, SL("name"), &name);
	if (!(Z_TYPE_P(&description) == IS_UNDEF) && Z_STRLEN_P(&description)) {
		zephir_update_property_zval(this_ptr, SL("description"), &description);
	}
	ZEPHIR_MM_RESTORE();

}

